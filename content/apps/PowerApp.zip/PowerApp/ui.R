#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)

# ui.R

#need to include includeCSS("www/isim_header.css") in the fluidpage environment
isimHeaderPanel <- function(appTitle,windowTitle=appTitle){
  tags$div(class="header",HTML(paste("<div class=\"text\"><h1>",as.character(appTitle),"</h1></div><div class=\"image\"></div>")))
}
# Written by N. Taback
# Aug. 11, 2023


# Define UI for application that draws a histogram
fluidPage(
  theme="bootswatch_cerulean.css",
  includeCSS("www/isim_header.css"),
  isimHeaderPanel("Investigating Power"),
  titlePanel(
    tags$div(
      tags$h2("Power of Testing a Single Proportion"),
      tags$p("Adjust the null and alternative values of p, sample size, alternative hypothesis, and significance level using the input fields below.",
             style = "color: grey; font-size: 14px;")
    )
  ),

    # Sidebar with a slider input for number of bins
    sidebarLayout(
        sidebarPanel(
            sliderInput("p0",
                        label = "Null Hypothesis Value of p:",
                        min = 0.1,
                        max = 0.9,
                        value = 0.2),
            sliderInput("p1",
                        "Alternative Hypothesis Value of p:",
                        min = 0.1,
                        max = 0.9,
                        value = 0.3),
            sliderInput("alpha",
                        label = "Significance Level",
                        min = 0.001,
                        max = 0.8,
                        value = 0.05),
            sliderInput("sample_range", "Sample Size Range:", 
                        min = 5, max = 1500, value = c(5, 50), step = 5),
            selectInput("AltHyp", 
                        label = "Alternative Hypothesis:",
                        choices = c("two.sided", "greater", "less"),
                        selected = "two.sided"),
            
        ),
        
        # Show a plot of the generated distribution
        mainPanel(
            plotOutput("powerplot"),
            tags$p("The table below displays the power values for different sample sizes based on the specified null value and alternative value"),
            verbatimTextOutput("Power Table"),
            tableOutput("powertable")
        )
    )
)



