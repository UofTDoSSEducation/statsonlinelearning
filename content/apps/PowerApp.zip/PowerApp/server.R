# Written by N. Taback
# Aug. 11, 2023


library(shiny)
library(tidyverse)
library(pwr)


function(input, output, session) {
  
  
  blank_plot <- ggplot2::ggplot() + ggplot2::theme_void()
  plot_data <- reactiveVal(blank_plot)
  table_data <- reactiveVal(data.frame())

  # Observe changes in p1, p0, or the sample size range
  observeEvent(list(input$p1, input$p0, input$sample_range, input$alpha, input$AltHyp), {
    samp_size <- seq(input$sample_range[1], input$sample_range[2], by = 5)
    y <- pwr::pwr.p.test(input$p1 - input$p0, n = samp_size, sig.level = input$alpha, alternative = input$AltHyp)
    
    powdf <- tibble::tibble(`Sample Size` = samp_size, Power = y$power)
    
    # Update the reactiveVals
    
    powplot <-ggplot2::ggplot(powdf, ggplot2::aes(`Sample Size`, Power)) + 
      ggplot2::geom_line() +
      ggplot2::ggtitle(expression(paste(" Power vs. Sample Size for testing ", 
                                        H[0], ": p=", p[0], " vs. ", H[1], ": p=", p[1]))) +
      ggplot2::xlab("Sample Size") + ggplot2::ylab("Power")
    
    plot_data(powplot)
    table_data(powdf)
  }, ignoreInit = FALSE)  # ignoreInit ensures the code runa on app initialization
  
  # Render the plot
  output$powerplot <- renderPlot({
    plot_data()
  })

  
  # Render the table
  
  output$tableDescription <- renderText({
    "This table displays the power values for different sample sizes based on the specified proportions"
  })
  
  output$powertable <- renderTable({
    table_data()
  })
  
}





